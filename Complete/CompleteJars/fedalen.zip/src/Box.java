public class Box {
	
	private static Crayon crayons[];
	// Note the order of creation should match the ordinal values of the colors.
	
	public Box() {
		
	}
	public void add(Crayon c1){
		
	}
	public Crayon remove(Color c1){
		return null;
	}
	public void sharpen(Crayon c1){
		
	}
	@Override
	public String toString(){
		return "";
	}
}
