public class Crayon implements Comparable<Box> {
	
	private Color col;
	private double len;
	
	public Crayon(double length, Color c1) {
		col = c1;
		len = length;
	}

	public String toString() {
		return "";
	}
	public Color getColor(){
		return col;
	}
	public double getLength(){
		return len;
	}
	public void setLength(double x){
		len = x;
	}
	public void compareTo(){
		
	}
	public void draw(){
		
	}

	@Override
	public int compareTo(Box arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
}